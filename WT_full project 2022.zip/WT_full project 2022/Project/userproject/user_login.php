<?php
    session_start();
    include("html/nav02.html");
?>
<html lang="en">
<head>
<meta charset="utf-8">
  <link rel="stylesheet" href="CSS/login.css">
</head>
<body>
    <div class="body">
      <form action="loginProcess.php" method="post" enctype="multipart/form-data">
  		<h2>Login as a User </h2> <br>


          	<input type="email" name="email" placeholder="Email" size="30" required="required">
             <br><br>
              <input type="password"  name="pass" placeholder="Password" size="30" required="required">
             <br><br>
              <button type="submit" name="save">Login</button>
              <br><br>
              Don't have an account? <a href="user_register.php">Register here</a>
      </form>
    </div>


</body>
</html>

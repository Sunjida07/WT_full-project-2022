<?php
    session_start();
    include("html/nav01.html");
    //include("html/serchbar.html");
    include("available_order.php");
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
      <link rel="stylesheet" href="css/dvr_ride.css">
  </head>
  <body>

      <script type="text/javascript" src="js/serbar.js"></script>




  </body>
</html>
